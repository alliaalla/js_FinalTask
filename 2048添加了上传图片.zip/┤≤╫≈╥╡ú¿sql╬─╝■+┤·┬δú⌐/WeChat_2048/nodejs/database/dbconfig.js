const mysql = require('mysql') // 导入mysql模块

var pool = mysql.createConnection({ // 创建mysql实例
  host: '127.0.0.1',
  port: '3306',
  user: 'root',
  password: '111',
  database: 'node'
});

module.exports = {
  pool
}