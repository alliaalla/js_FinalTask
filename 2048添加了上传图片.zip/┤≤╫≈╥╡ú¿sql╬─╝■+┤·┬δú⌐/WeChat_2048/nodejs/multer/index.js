const express = require('express')
let { pool } = require("../database/dbconfig.js")
const router = express.Router()
const multer  = require('multer')
const { json } = require('express/lib/response')
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'header/image')
    //文件保存路径
  },
  filename: function (req, file, cb) {
    console.log(file.originalname)
    cb(null, file.originalname)
    //存储文件名
  }
})
 
var upload = multer({ storage: storage })

// upload.single()是指定二级路径，这里要注意，前端提交请求时的key一定是这里二级路径的名字，不然会报MulterError: Unexpected field
router.post('/upload',upload.single('imgsrc'), (req, res, next)=> {
  let file = req.file;
  let sql = "update user set user_img = ? where id = ?;" //sql语句
  var params = ["http://localhost:3000/image/get/"+file.originalname,req.body.id]; //sql语句中的参数，数组，顺序要和sql语句中的顺序一致，几个问号就是几个参数
  console.log(file.originalname);
  console.log(req.body.id);
  pool.query(sql, params, function (error, result) {
    if (error || result == "") { //有错误或者查询结果为空
      
      console.log("更新失败")
    } else { //成功
      
      console.log("更新成功，结果是: "+file.originalname,req.body.id)
    }
  });
  //上面这两行可写可不写的，目的是log一下知道req.file能拿到上传得到文件的信息，拿到文件之后做什么操作看具体业务需求
  res.send('上传完成')
});

module.exports=router
