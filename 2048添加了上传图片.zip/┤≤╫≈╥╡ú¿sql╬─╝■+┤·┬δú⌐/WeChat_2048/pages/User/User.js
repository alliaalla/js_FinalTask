var app = getApp()
var zyy_is = false;
Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
    imgs: [],
    user:[],
  },
  onLoad(options) {
    this.searchUsers(),
    this.setData({
      canIUseGetUserProfile: true,
      hasUserInfo:app.globalData.has,
      userInfo:app.globalData.user,
      user_name:app.globalData.user.nickName
    })
},
  searchUsers:function() {
    var that = this
    let resultpromise = new Promise(function(resolve, reject){
      wx.request({
        url: 'http://127.0.0.1:3000/user/getUser/'+app.globalData.user_id,
        header:{
          'content-type': 'application/json'
        },
        method:'GET',
        success: (res) =>{
          that.setData({
            user: res.data.msg
          })
          console.log("msg:"+that.data.user)
          console.log("msg:"+app.globalData.user.nickName)
        },
        fail:() =>{
          reject(res)
        }
      })     
    })
    return resultpromise
  },
  chooseImg: function (e) {
    var that = this
    wx.chooseImage({
      count: 1, 
      sizeType: ['original', 'compressed'], 
      sourceType: ['album'], 
      success: function(res) {
        wx.uploadFile({
          url: 'http://127.0.0.1:3000/img/upload', 
          filePath: res.tempFilePaths[0],
          name: 'imgsrc',
          formData:{
            'id': app.globalData.user_id
          },
          success: function(res){
            that.onLoad()
            console.log(res)
          }
        })
      }
    })
  },
})
